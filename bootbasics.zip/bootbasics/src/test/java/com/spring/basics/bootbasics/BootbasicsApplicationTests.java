package com.spring.basics.bootbasics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootbasicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
